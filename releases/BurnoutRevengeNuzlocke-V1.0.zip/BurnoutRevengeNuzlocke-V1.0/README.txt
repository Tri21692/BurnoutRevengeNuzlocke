BURNOUT REVENGE NUZLOCKE  -  V1.0
=================================

A Nuzlocke challenge mod for Burnout Revenge (PS2, USA, SLUS-21242) in PCSX2 2.x on Windows.

  - Every car has limited lives: 3 (Easy), 2 (Medium) or 1 (Hard).
  - Every event must end in Gold + Perfect, or the car you drove loses a life.
  - Cars with no lives left become [WRECKED] and can't be selected.
  - Retry and Quit in the pause menu don't work: every event has to be finished.
  - Optional Harder AI (Easy / Medium / Hard): faster cornering, no easing off, strong catch-up.

WHAT'S IN THIS PACKAGE

  nuzlocke.exe                  The tracker: judges results, counts lives, stats, stream overlay.
  nuzlocke_isopatch.exe         Builds the mod into a copy of your own ISO (one ISO per AI level).
  SLUS-21242_D224D348.pnach     The mod as a PCSX2 patch file (use this OR a patched ISO).
  Start-up Guide.md             Full setup, good practices, FAQ and troubleshooting.

QUICK START

  1. PCSX2: Settings > Advanced > turn on PINE (slot 28011).
  2. Add the mod, EITHER:
       a) Copy SLUS-21242_D224D348.pnach into PCSX2's "patches" folder. In the game's
          Properties > Patches, tick "Block dead cars in garage", "Block pause-menu Retry and
          Quit" and ONE "Harder AI" level (optional). Restart the game.
     OR
       b) Drag your clean Burnout Revenge ISO onto nuzlocke_isopatch.exe, choose Easy, Medium or
          Hard, and play the new ISO it makes (with the .pnach turned off).
  3. Run nuzlocke.exe from a folder of its own. Its control page opens at http://localhost:8765.
     Pick a difficulty to start a run, then play World Tour.
  4. Streaming: in OBS add a Browser Source with http://localhost:8765/overlay (about 800 x 400).

Back up your memory card first, use a fresh card for each run, and don't use save states during a
run. See "Start-up Guide.md" for the details.

No game files are included: you need your own copy of the game. Patched ISOs contain the game, so
don't share them; share this package instead.

Fan project, not affiliated with or endorsed by Criterion Games or Electronic Arts.
GitHub: https://github.com/Tri21692/BurnoutRevengeNuzlocke
