BURNOUT REVENGE NUZLOCKE  -  V2.0 "Fun + Pain"
==============================================

A Nuzlocke challenge mod for Burnout Revenge (PS2, USA, SLUS-21242) in PCSX2 2.x on Windows.

THE RULES
  - Every car has two pools of lives, Race and Crash: 3+3 (Easy), 2+2 (Medium) or 1+1 (Hard).
    Crash junctions use the Crash pool, every other event the Race pool.
  - Every event needs at least Silver + Great (Easy), Silver + Awesome (Medium) or a first-time
    Gold + Perfect (Hard), or the car you drove loses a life from that pool.
  - Out of Race lives: [RACE X]. Out of Crash lives: [CRASH X]. Out of both: [WRECKED].
  - Retry and Quit in the pause menu don't work, and Retry on the results screen just continues.
  - The run is dead when every car that can race is wrecked for races, or every crash car is
    wrecked for crash junctions. Every car is then blocked until you choose Grace or a new run.
  - Cars loaned by Burning Laps and Preview events only count once you unlock them.
  - Optional Harder AI: Easy / Medium / Hard / Insane. Faster opponents that go for takedowns.

NEW IN V2.0 (optional modes, switched on in the patch or the ISO patcher)
  - Limited Selection: before every event you get 2 random cars for races and 2 for crash
    junctions; the rest are [BENCHED]. Never the same car twice in a row.
  - Revive tokens: win streaks earn tokens that give a wrecked car a life back (every 3 wins
    in a row on Easy, 5 on Medium, 8 on Hard).
  - Event Roulette: the tracker picks your next event from every rank; every other event is
    locked on the map. One reroll to start, one more per rank you win in. Optionally, Unlock
    all cars.
  - Achievements (standard runs only) and an end-of-run summary, also saved as a text file.

UPGRADING
  Replace all three files below and remake any patched ISOs. Your current run carries over.

WHAT'S IN THIS PACKAGE
  nuzlocke.exe                  The tracker: judges results, counts lives, stats, stream overlay.
  nuzlocke_isopatch.exe         Builds the mod into a copy of your own ISO.
  SLUS-21242_D224D348.pnach     The mod as a PCSX2 patch file (use this OR a patched ISO).
  Start-up Guide.md             Full setup, modes, good practices, FAQ and troubleshooting.

QUICK START
  1. PCSX2: Settings > Advanced > turn on PINE (slot 28011).
  2. Add the mod, EITHER:
       a) Copy SLUS-21242_D224D348.pnach into PCSX2's "patches" folder. In the game's
          Properties > Patches, tick "Block dead cars in garage", "Block pause-menu Retry and
          Quit", ONE "Harder AI" level (optional), any "Mode" you want, and "Widescreen 16:9" /
          "60 FPS menus and crash mode" if you like. Restart the game.
     OR
       b) Drag your clean Burnout Revenge ISO onto nuzlocke_isopatch.exe, choose a level, the
          modes and the extras, and play the new ISO it makes (with the .pnach turned off).
  3. Run nuzlocke.exe from a folder of its own. Its control page opens at http://localhost:8765.
     Pick a difficulty to start a run, then play World Tour.
  4. Streaming: in OBS add a Browser Source with http://localhost:8765/overlay (about 800 x 400).

Back up your memory card first, use a fresh card for each run (Event Roulette especially), and
don't use save states during a run. See "Start-up Guide.md" for the details.

No game files are included: you need your own copy of the game. Patched ISOs contain the game, so
don't share them; share this package instead.

Widescreen and 60 FPS: "16:9 HUD Scale & 60 FPS Fix" by SuperType1/remco.
Fan project, not affiliated with or endorsed by Criterion Games or Electronic Arts.
GitHub: https://github.com/Tri21692/BurnoutRevengeNuzlocke
